# Chance Day-Spicer
# Interactive Fiction


def introduction():
  print "The year is 2089. Neon skies light up what used to be the night.  It was a cold and dark night, full of death.\n"
  print "You are in an alleyway. A stranger approaches you.\n"
  nextline01()     		


def nextline01():
  print "Do you... \n A- Ask the stranger to stop and show himself \n or \n B- draw your pocketknife as the stranger gets closer."
  stranger = raw_input()
  stranger = stranger.lower()
  if stranger == "a":
    print "You asked the stranger to Stop, but he doesn't. You can pull out a pocketknife or ask the starnger to stop again"
  elif stranger == "b":
    print "You have a pocketknife"
  weaponchoose01()

def weaponchoose01():
  print "Which do you use? \n A- Pocketknife \n Or \n B- Pack of gum."
  weapon = raw_input()
  weapon = weapon.upper()
  if weapon == "a":
   print "The stranger comes closer as you draw your pocketknife"
  if weapon == "b":
   print "The stranger comes closer. You begin to draw your pocket knife " 
  action01()

def 

def action01():
  print "The stranger. The End"
introduction()


